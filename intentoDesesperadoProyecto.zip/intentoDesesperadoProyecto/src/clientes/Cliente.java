package clientes;

public class Cliente {
    private String nombre, direccion, telefono, codigoCliente;

    public Cliente() {
    }

    public Cliente(String nombre, String direccion, String telefono, String codigoCliente) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
        this.codigoCliente = codigoCliente;
    }

    public String getNombre() {
        return nombre;
    }

    public String getcodigoCliente() {
        return codigoCliente;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setcodigoCliente(String clienteAmigo) {
        this.codigoCliente = clienteAmigo;
    }

    @Override
    public String toString() {
        return "Cliente{" +
                "nombre='" + nombre + '\'' +
                ", direccion='" + direccion + '\'' +
                ", telefono='" + telefono + '\'' +
                ", clienteAmigo='" + codigoCliente + '\'' +
                '}';
    }
}
